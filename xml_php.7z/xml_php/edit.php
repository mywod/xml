<?php
	session_start();
	if(isset($_POST['edit'])){
		$users = simplexml_load_file('files/members.xml');
		foreach($users->user as $user){
			if($user->id == $_POST['id']){
				$user->esercizio = $_POST['esercizio'];
				$user->max_rep = $_POST['max_rep'];
				$user->max_peso = $_POST['max_peso'];
				break;
			}
		}
		file_put_contents('files/members.xml', $users->asXML());
		$_SESSION['message'] = 'Member updated successfully';
		header('location: index.php');
	}
	else{
		$_SESSION['message'] = 'Select member to edit first';
		header('location: index.php');
	}

?>