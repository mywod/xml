<?php
	session_start();
	if(isset($_POST['add'])){
		//open xml file
		$users = simplexml_load_file('files/members.xml');
		$user = $users->addChild('user');
		
		$user->addChild('id', $_POST["id"]);
		$user->addChild('esercizio', $_POST['esercizio']);
		$user->addChild('max_rep', $_POST['max_rep']);
		$user->addChild('max_peso', $_POST['max_peso']);
		
		// Save to file
		// file_put_contents('files/members.xml', $users->asXML());
		// Prettify / Format XML and save
		$dom = new DomDocument();
		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;
		$dom->loadXML($users->asXML());
		$dom->save('files/members.xml');
		// Prettify / Format XML and save

		$_SESSION['message'] = 'Member added successfully';
		header('location: index.php');
	}
	else{
		$_SESSION['message'] = 'Fill up add form first';
		header('location: index.php');
	}

?>